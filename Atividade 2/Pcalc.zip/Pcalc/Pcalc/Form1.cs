﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnsair_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Você deseja mesmo sair? ", "Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

        private void txtnumero2_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider2.SetError(txtnumero2, "");
                numero2 = Convert.ToDouble(txtnumero2.Text);
            }
            catch(Exception ex)
            {
                errorProvider2.SetError(txtnumero2, "Número 2 inválido");
               // MessageBox.Show("Número Inválido");
                txtnumero2.Focus();
            }
        }

        private void btnmais_Click(object sender, EventArgs e)
        {
            errorProvider2.SetError(txtnumero2, "");
            resultado = numero1 + numero2;
            txtresultado.Text = resultado.ToString("");
        }

        private void btnmenos_Click(object sender, EventArgs e)
        {
            errorProvider2.SetError(txtnumero2, "");
            resultado = numero1 - numero2;
            txtresultado.Text = resultado.ToString("");
        }

        private void btnmult_Click(object sender, EventArgs e)
        {
            errorProvider2.SetError(txtnumero2, "");
            resultado = numero1 * numero2;
            txtresultado.Text = resultado.ToString("");
        }

        private void btndiv_Click(object sender, EventArgs e)
        {
          if(numero2 == 0)
            {
                MessageBox.Show("Não pode dividir por zero!!!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtnumero2.Focus();
            }
            else
            {
                errorProvider2.SetError(txtnumero2, "");
                resultado = numero1/numero2;
                txtresultado.Text = resultado.ToString();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            txtnumero1.Clear();
            txtnumero2.Clear();
            txtresultado.Clear();
        }

        private void txtnumero1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtnumero1.Text, out numero1))
            {
                errorProvider1.SetError(txtnumero1, "Número 1 inválido");
                //  MessageBox.Show("Número inválido");
                txtnumero1.Focus();
            }
            else
                errorProvider1.SetError(txtnumero1, "");
        }
    }
}
