﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ploops
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnPalin_Click(object sender, EventArgs e)
        {
            string str = txtboxPalin.Text.ToString();

            string str2 = str.ToUpper();

            string str3 = str2.Replace(" ","");

            char[] cArray = str3.ToCharArray();

            Array.Reverse (cArray);

            string str4 = new string(cArray);



            if (str4 != str3)
            {
                MessageBox.Show("Sua palavra ou frase não é um palindromo");
            }
            else 
            {
                MessageBox.Show("A palavra/frase: " + str + " é um palindromo!\n"+str3);
            }
          
        }
    }
}
