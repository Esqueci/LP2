﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ploops
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            int c, Branco;
            c = 0;
            Branco = 0;

            while (c < rchboxFrase.TextLength)
            {
                if (rchboxFrase.Text[c] == ' ')
                    Branco++;
                c++;
            }
            MessageBox.Show("Seu texto tem " + Branco + " espaços em branco");
        }

     
        private void btnPares_Click(object sender, EventArgs e)
        {
            int  pares;
            char letraAnt = '\0';
           
            pares = 0;

            foreach (char s in  rchboxFrase.Text)
            {
                if (s== letraAnt)
                    pares++;

                letraAnt = s;
            }
            MessageBox.Show("Seu texto tem " + pares + " pares");
        }

        private void btnR_Click(object sender, EventArgs e)
        {
            int i, r;
            i = 0;
            r = 0;

            for (i = 0; i < rchboxFrase.TextLength;)
            {
                if (rchboxFrase.Text[i] == 'R' || rchboxFrase.Text[i] == 'r')
                    r++;
                i++;
            }
            MessageBox.Show("Seu texto tem " + r + "   R ou r");
        }
    }
}
