﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ploops
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double A, B = 0, C = 0, D = 0, salBruto, prod, grat;

            double.TryParse(txtboxGrat.Text, out grat);
            double.TryParse(txtboxProd.Text, out prod);
            double.TryParse(txtboxSal.Text, out A);

            if (prod >= 100)
                B = 1;
            else
            {
                if (prod >= 120)
                    C = 1;
                else
                {
                    if (prod >= 150)
                        D = 1;
                }
            }
            salBruto = A + A * (0.05 * B + 0.1 * C + 0.1 * D) + grat;

            if (salBruto > 7000)
            {
                if (prod < 150 || grat <= 0)
                {
                    salBruto = 7000;
                }
            }

            MessageBox.Show(txtboxNome.Text + ", seu salário bruto é:\n" + salBruto);
            txtboxSalbruto.Text = salBruto.ToString();
        }
    }
}
