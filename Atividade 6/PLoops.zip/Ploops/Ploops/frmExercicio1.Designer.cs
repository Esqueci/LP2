﻿namespace Ploops
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBranco = new System.Windows.Forms.Button();
            this.rchboxFrase = new System.Windows.Forms.RichTextBox();
            this.btnR = new System.Windows.Forms.Button();
            this.btnPares = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnBranco
            // 
            this.btnBranco.Location = new System.Drawing.Point(207, 316);
            this.btnBranco.Name = "btnBranco";
            this.btnBranco.Size = new System.Drawing.Size(108, 69);
            this.btnBranco.TabIndex = 0;
            this.btnBranco.Text = "Espaços em Branco";
            this.btnBranco.UseVisualStyleBackColor = true;
            this.btnBranco.Click += new System.EventHandler(this.btnBranco_Click);
            // 
            // rchboxFrase
            // 
            this.rchboxFrase.Location = new System.Drawing.Point(207, 97);
            this.rchboxFrase.MaxLength = 100;
            this.rchboxFrase.Name = "rchboxFrase";
            this.rchboxFrase.Size = new System.Drawing.Size(368, 187);
            this.rchboxFrase.TabIndex = 1;
            this.rchboxFrase.Text = "";
            // 
            // btnR
            // 
            this.btnR.Location = new System.Drawing.Point(340, 316);
            this.btnR.Name = "btnR";
            this.btnR.Size = new System.Drawing.Size(108, 69);
            this.btnR.TabIndex = 2;
            this.btnR.Text = "Letras \"R\"";
            this.btnR.UseVisualStyleBackColor = true;
            this.btnR.Click += new System.EventHandler(this.btnR_Click);
            // 
            // btnPares
            // 
            this.btnPares.Location = new System.Drawing.Point(467, 316);
            this.btnPares.Name = "btnPares";
            this.btnPares.Size = new System.Drawing.Size(108, 69);
            this.btnPares.TabIndex = 3;
            this.btnPares.Text = "Pares de letras";
            this.btnPares.UseVisualStyleBackColor = true;
            this.btnPares.Click += new System.EventHandler(this.btnPares_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(317, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 24);
            this.label1.TabIndex = 4;
            this.label1.Text = "Digite a frase";
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnPares);
            this.Controls.Add(this.btnR);
            this.Controls.Add(this.rchboxFrase);
            this.Controls.Add(this.btnBranco);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnBranco;
        private System.Windows.Forms.RichTextBox rchboxFrase;
        private System.Windows.Forms.Button btnR;
        private System.Windows.Forms.Button btnPares;
        private System.Windows.Forms.Label label1;
    }
}