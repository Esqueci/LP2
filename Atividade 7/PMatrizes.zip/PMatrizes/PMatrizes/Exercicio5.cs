﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class Exercicio5 : Form
    {
        public Exercicio5()
        {
            InitializeComponent();
        }

        private void btnVeri_Click(object sender, EventArgs e)
        {
            char[,] resp = new char[2, 10];
            char[] gab = new char[10] { 'A', 'B', 'C', 'D', 'E', 'A', 'B', 'C', 'D', 'E' };
            char[] vetor = new char[5] { 'A', 'B', 'C', 'D', 'E' };
            int c = 0;
            string auxiliar = "";

            for (int i = 0; i < 2; i++)
            {
                for(c = 0; c < 10; c++)
                {
                    auxiliar = Interaction.InputBox($"Resposta da {c + 1}º Questão", "Entrada de dados");

                    if(!char.TryParse(auxiliar, out resp[i, c]) || !vetor.Contains(resp[i, c]))
                        {
                        MessageBox.Show("Digito inválido");
                        c--;
                    }
                    else
                    {
                        if (resp[i, c] == gab[c])
                        {
                            auxiliar = "";
                            auxiliar += $"O aluno {i + 1} acertou a questão {c + 1} era {gab[c]} escolheu {resp[i, c]}";
                            lboxLista.Items.Add(auxiliar);
                        }
                        else
                        {
                            auxiliar += $"O aluno {i + 1} errou a questão {c + 1} era {gab[c]} escolheu {resp[i, c]}";
                            lboxLista.Items.Add(auxiliar);
                        }
                    }

                }
            }


        }
    }
}
