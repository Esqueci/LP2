﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExerc1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";


            for (int i = 0; i <= 19; i++)
            {
                auxiliar = Interaction.InputBox("Digite o número", "Entrada de Dados");

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("número inválido!");
                    i--;
                }
            }
            Array.Reverse(vetor);
            auxiliar = "";
            foreach (int x in vetor)
            {
                auxiliar += x + "\n";
            }
            MessageBox.Show(auxiliar);

        }

        private void btnExerc2_Click(object sender, EventArgs e)
        {
            ArrayList lista = new ArrayList() { "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais" };
            lista.Remove("Otávio");
            string auxiliar = "";

            foreach (string s in lista)
            {
                auxiliar += s + "\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void btnExerci3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            double[] media = new double[20];
            string auxiliar = "";
            double media2 = 0;

            for (var aluno = 0; aluno < 20; aluno++)
            {
                for (var nota = 0; nota < 3; nota++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota {nota+1}º ", $"Notas do aluno {aluno+1}");
                    if (!double.TryParse(auxiliar, out notas[aluno, nota]))
                    {
                        MessageBox.Show("Digito Inválido, digite números de 0 a 10");
                        nota--;
                    }
                    else if (notas[aluno, nota] < 0 || notas[aluno, nota] > 10)
                    {
                        MessageBox.Show("Digite um número de 0 a 10");
                        nota--;
                    }
                    else
                    {
                        media2 = media2 + notas[aluno, nota];
                    }
                }
                media2 = media2 / 3;
                media[aluno] = media2;
                media2 = 0;

            }
            auxiliar = "";
            for (int c = 0; c < 20; c++)
            {
                    auxiliar +="Aluno "+(c+1).ToString()+" média: " + media[c] +"\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void btnExerci4_Click(object sender, EventArgs e)
        {
            Exercicio4 Exercicio4 = new Exercicio4();
            Exercicio4.ShowDialog();
        }

        private void btnExerci5_Click(object sender, EventArgs e)
        {
            Exercicio5 Exercicio5 = new Exercicio5();
            Exercicio5.ShowDialog();
        }
    }
}
