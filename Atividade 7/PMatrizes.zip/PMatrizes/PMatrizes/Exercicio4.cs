﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class Exercicio4 : Form
    {
        public Exercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] vetor = new string[10];
            int[] carac = new int[10];
            string auxiliar = "";
            int contLetras = 0;

            for (int i = 0; i < 10 ; i++)
            {
                vetor[i] = Interaction.InputBox($"Digite {i+1}º nome", "Entrada de nomes");
                
                for (int c = 0; c < vetor[i].Length; c++)
                {
                    if (vetor[i][c] != ' ')
                    {
                        contLetras++;
                    }
                }
                carac[i] = contLetras;
                contLetras = 0;
            }
            for (int i = 0; i < 10 ; i++)
            {
                auxiliar += "O nome: " + vetor[i] + " tem "+carac[i]+" caracteres"+"\n";
                lboxLista.Items.Add(auxiliar);
                auxiliar = "";
            }
        }
    }
}
