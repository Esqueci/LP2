﻿namespace PMatrizes
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExerc1 = new System.Windows.Forms.Button();
            this.btnExerc2 = new System.Windows.Forms.Button();
            this.btnExerci3 = new System.Windows.Forms.Button();
            this.btnExerci4 = new System.Windows.Forms.Button();
            this.btnExerci5 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnExerc1
            // 
            this.btnExerc1.Location = new System.Drawing.Point(210, 34);
            this.btnExerc1.Name = "btnExerc1";
            this.btnExerc1.Size = new System.Drawing.Size(199, 138);
            this.btnExerc1.TabIndex = 0;
            this.btnExerc1.Text = "Exercicio 1";
            this.btnExerc1.UseVisualStyleBackColor = true;
            this.btnExerc1.Click += new System.EventHandler(this.btnExerc1_Click);
            // 
            // btnExerc2
            // 
            this.btnExerc2.Location = new System.Drawing.Point(463, 34);
            this.btnExerc2.Name = "btnExerc2";
            this.btnExerc2.Size = new System.Drawing.Size(199, 138);
            this.btnExerc2.TabIndex = 1;
            this.btnExerc2.Text = "Exercicio 2";
            this.btnExerc2.UseVisualStyleBackColor = true;
            this.btnExerc2.Click += new System.EventHandler(this.btnExerc2_Click);
            // 
            // btnExerci3
            // 
            this.btnExerci3.Location = new System.Drawing.Point(210, 178);
            this.btnExerci3.Name = "btnExerci3";
            this.btnExerci3.Size = new System.Drawing.Size(199, 139);
            this.btnExerci3.TabIndex = 2;
            this.btnExerci3.Text = "Exercicio 3";
            this.btnExerci3.UseVisualStyleBackColor = true;
            this.btnExerci3.Click += new System.EventHandler(this.btnExerci3_Click);
            // 
            // btnExerci4
            // 
            this.btnExerci4.Location = new System.Drawing.Point(463, 178);
            this.btnExerci4.Name = "btnExerci4";
            this.btnExerci4.Size = new System.Drawing.Size(199, 139);
            this.btnExerci4.TabIndex = 3;
            this.btnExerci4.Text = "Exercicio 4";
            this.btnExerci4.UseVisualStyleBackColor = true;
            this.btnExerci4.Click += new System.EventHandler(this.btnExerci4_Click);
            // 
            // btnExerci5
            // 
            this.btnExerci5.Location = new System.Drawing.Point(210, 323);
            this.btnExerci5.Name = "btnExerci5";
            this.btnExerci5.Size = new System.Drawing.Size(452, 88);
            this.btnExerci5.TabIndex = 4;
            this.btnExerci5.Text = "Exercicio 5";
            this.btnExerci5.UseVisualStyleBackColor = true;
            this.btnExerci5.Click += new System.EventHandler(this.btnExerci5_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(842, 450);
            this.Controls.Add(this.btnExerci5);
            this.Controls.Add(this.btnExerci4);
            this.Controls.Add(this.btnExerci3);
            this.Controls.Add(this.btnExerc2);
            this.Controls.Add(this.btnExerc1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnExerc1;
        private System.Windows.Forms.Button btnExerc2;
        private System.Windows.Forms.Button btnExerci3;
        private System.Windows.Forms.Button btnExerci4;
        private System.Windows.Forms.Button btnExerci5;
    }
}

