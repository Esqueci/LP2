﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pnotebook02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lboxTexto.Items.Clear();

        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[,] matriz = new double[2, 3];
            double[] notebook = new double[2];
            double Loja1 = 0;
            double Loja2 = 0;
            double Loja3 = 0;
            double Media = 0;
            int c = 0;
            string auxiliar = "";

            for (int i = 0; i < 2; i++)
            {

                for (c = 0; c < 3; c++)
                {
                    auxiliar = Interaction.InputBox($"Modelo Notebook {i + 1}, loja {c + 1} ", "Entrada de dados");
                    double Valauxiliar = 0;
                    double.TryParse(auxiliar, out Valauxiliar);

                    if (!double.TryParse(auxiliar, out matriz[i, c])|| Valauxiliar < 0)
                    {
                        MessageBox.Show("Valor inválido");
                        c--;
                    }
                    else
                    {
                        Loja1 = matriz[i, 0];
                        Loja2 = matriz[i, 1];
                        Loja3 = matriz[i, 2];
                    }

                }
    
                Media = (Loja3 + Loja2 + Loja1) / 3;
                notebook[i] = Media;
                auxiliar = "";
                Media = Math.Round(Media, 2);
                auxiliar += $"Notebook{i + 1}  Loja1: R${Loja1}  Loja2: R${Loja2}  Loja3: R${Loja3} Media:{Media}\n";
                lboxTexto.Items.Add(auxiliar);


            }
            double mediaGeral = (notebook[0] + notebook[1]) / 2;
            auxiliar = "";
            mediaGeral = Math.Round(mediaGeral, 2);
            auxiliar += $"\nMédia Geral Computadores: R${mediaGeral}";
            lboxTexto.Items.Add(auxiliar);

        }

    }
}
