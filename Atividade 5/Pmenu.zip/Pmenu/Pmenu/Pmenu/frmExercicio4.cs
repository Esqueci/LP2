﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmenu
{
    public partial class frmExercicio4 : Form
    {

        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnnumero_Click(object sender, EventArgs e)
        {
            int c;
            int cNum;
            cNum = 0;
            c = 0;
            while (c < rchtxtfrase.Text.Length)
            {
                if (char.IsNumber(rchtxtfrase.Text[c]))
                {
                    cNum = cNum++;
                }
                c++;
            }
            MessageBox.Show(cNum.ToString());
        }

        private void btnletra_Click(object sender, EventArgs e)
        {
            int c;

            int tamanho = rchtxtfrase.Text.Length;
            int cLetra;
            cLetra = 0;
            c = 0;
            while (c < tamanho)
            {
                if (char.IsLetter(rchtxtfrase.Text[c]))
                {
                    cLetra = cLetra +1;
                }
                c++;
            }
            MessageBox.Show(cLetra.ToString());
        }
    }
}
