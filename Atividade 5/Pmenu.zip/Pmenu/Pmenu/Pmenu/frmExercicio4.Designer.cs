﻿namespace Pmenu
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtfrase = new System.Windows.Forms.RichTextBox();
            this.btnnumero = new System.Windows.Forms.Button();
            this.btncharbranco = new System.Windows.Forms.Button();
            this.btnletra = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtfrase
            // 
            this.rchtxtfrase.Location = new System.Drawing.Point(189, 43);
            this.rchtxtfrase.Name = "rchtxtfrase";
            this.rchtxtfrase.Size = new System.Drawing.Size(423, 98);
            this.rchtxtfrase.TabIndex = 0;
            this.rchtxtfrase.Text = "";
            // 
            // btnnumero
            // 
            this.btnnumero.Location = new System.Drawing.Point(189, 180);
            this.btnnumero.Name = "btnnumero";
            this.btnnumero.Size = new System.Drawing.Size(132, 119);
            this.btnnumero.TabIndex = 1;
            this.btnnumero.Text = "Quantidade de números";
            this.btnnumero.UseVisualStyleBackColor = true;
            this.btnnumero.Click += new System.EventHandler(this.btnnumero_Click);
            // 
            // btncharbranco
            // 
            this.btncharbranco.Location = new System.Drawing.Point(327, 147);
            this.btncharbranco.Name = "btncharbranco";
            this.btncharbranco.Size = new System.Drawing.Size(147, 119);
            this.btncharbranco.TabIndex = 2;
            this.btncharbranco.Text = "Primeiro caracter branco";
            this.btncharbranco.UseVisualStyleBackColor = true;
            // 
            // btnletra
            // 
            this.btnletra.Location = new System.Drawing.Point(480, 180);
            this.btnletra.Name = "btnletra";
            this.btnletra.Size = new System.Drawing.Size(132, 119);
            this.btnletra.TabIndex = 3;
            this.btnletra.Text = "Quantidade de letras";
            this.btnletra.UseVisualStyleBackColor = true;
            this.btnletra.Click += new System.EventHandler(this.btnletra_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnletra);
            this.Controls.Add(this.btncharbranco);
            this.Controls.Add(this.btnnumero);
            this.Controls.Add(this.rchtxtfrase);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtfrase;
        private System.Windows.Forms.Button btnnumero;
        private System.Windows.Forms.Button btncharbranco;
        private System.Windows.Forms.Button btnletra;
    }
}