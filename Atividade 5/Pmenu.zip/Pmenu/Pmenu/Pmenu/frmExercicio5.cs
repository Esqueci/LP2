﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmenu
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSorteio_Click(object sender, EventArgs e)
        {
            Double num1, num2;

            if ((Double.TryParse(txtNumero1.Text, out num1)) && (Double.TryParse(txtNumero2.Text, out num2)))
            {
                if ((num1 >= 0) && (num2 >= 0) && (num2 >= num1))
                {
                    Random objR = new Random();
                    double sorteado = objR.Next((int)num1, (int)num2);
                    MessageBox.Show("Numero: " + sorteado.ToString());
                }
                else
                    MessageBox.Show("Invalido"); ;
            }
            else
                MessageBox.Show("Invalido");
        }
    }
}
