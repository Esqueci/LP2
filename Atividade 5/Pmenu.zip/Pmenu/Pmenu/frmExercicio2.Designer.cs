﻿namespace Pmenu
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPalavra1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.lblPalavra2 = new System.Windows.Forms.Label();
            this.btnverificar = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.lblPalavra3 = new System.Windows.Forms.Label();
            this.btninserirast = new System.Windows.Forms.Button();
            this.btninserir = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblPalavra1
            // 
            this.lblPalavra1.AutoSize = true;
            this.lblPalavra1.Location = new System.Drawing.Point(304, 61);
            this.lblPalavra1.Name = "lblPalavra1";
            this.lblPalavra1.Size = new System.Drawing.Size(52, 13);
            this.lblPalavra1.TabIndex = 0;
            this.lblPalavra1.Text = "Palavra 1";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(362, 58);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(128, 20);
            this.textBox1.TabIndex = 1;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(362, 99);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(128, 20);
            this.textBox2.TabIndex = 2;
            // 
            // lblPalavra2
            // 
            this.lblPalavra2.AutoSize = true;
            this.lblPalavra2.Location = new System.Drawing.Point(304, 102);
            this.lblPalavra2.Name = "lblPalavra2";
            this.lblPalavra2.Size = new System.Drawing.Size(52, 13);
            this.lblPalavra2.TabIndex = 3;
            this.lblPalavra2.Text = "Palavra 2";
            // 
            // btnverificar
            // 
            this.btnverificar.Location = new System.Drawing.Point(262, 215);
            this.btnverificar.Name = "btnverificar";
            this.btnverificar.Size = new System.Drawing.Size(112, 72);
            this.btnverificar.TabIndex = 5;
            this.btnverificar.Text = "Verificar Iguais";
            this.btnverificar.UseVisualStyleBackColor = true;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(362, 145);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(128, 20);
            this.textBox3.TabIndex = 7;
            // 
            // lblPalavra3
            // 
            this.lblPalavra3.AutoSize = true;
            this.lblPalavra3.Location = new System.Drawing.Point(304, 148);
            this.lblPalavra3.Name = "lblPalavra3";
            this.lblPalavra3.Size = new System.Drawing.Size(52, 13);
            this.lblPalavra3.TabIndex = 8;
            this.lblPalavra3.Text = "Palavra 3";
            // 
            // btninserirast
            // 
            this.btninserirast.Location = new System.Drawing.Point(498, 215);
            this.btninserirast.Name = "btninserirast";
            this.btninserirast.Size = new System.Drawing.Size(112, 72);
            this.btninserirast.TabIndex = 9;
            this.btninserirast.Text = "Inserir 2 Asteristicos";
            this.btninserirast.UseVisualStyleBackColor = true;
            // 
            // btninserir
            // 
            this.btninserir.Location = new System.Drawing.Point(380, 215);
            this.btninserir.Name = "btninserir";
            this.btninserir.Size = new System.Drawing.Size(112, 72);
            this.btninserir.TabIndex = 10;
            this.btninserir.Text = "Inserir 1º meio 2º";
            this.btninserir.UseVisualStyleBackColor = true;
            // 
            // frmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(797, 461);
            this.Controls.Add(this.btninserir);
            this.Controls.Add(this.btninserirast);
            this.Controls.Add(this.lblPalavra3);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.btnverificar);
            this.Controls.Add(this.lblPalavra2);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lblPalavra1);
            this.Name = "frmExercicio2";
            this.Text = "frmExercicio2";
            this.Load += new System.EventHandler(this.frmExercicio2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPalavra1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label lblPalavra2;
        private System.Windows.Forms.Button btnverificar;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label lblPalavra3;
        private System.Windows.Forms.Button btninserirast;
        private System.Windows.Forms.Button btninserir;
    }
}